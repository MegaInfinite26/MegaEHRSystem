<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Add Medical History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .form-card { max-width:720px; margin:auto; border:0; border-radius:16px; }
        .field-error { color:#dc3545; font-size:.875rem; display:block; margin-top:.25rem; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/patients/${patient.id}/history">Medical History</a>
    </div>
</nav>
<div class="container py-5">
    <div class="card form-card shadow-sm">
        <div class="card-body p-4 p-md-5">
            <h2 class="fw-bold mb-1">Add Medical History</h2>
            <p class="text-muted mb-4">${patient.name} | ${patient.patientCode}</p>

            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger">${errorMessage}</div>
            </c:if>

            <form:form method="post"
                       action="${pageContext.request.contextPath}/patients/${patient.id}/history"
                       modelAttribute="history">
                <div class="mb-3">
                    <label for="historyType" class="form-label fw-semibold">History Type</label>
                    <form:select path="historyType" id="historyType" cssClass="form-select">
                        <form:option value="" label="Select history type" />
                        <form:option value="PAST_ILLNESS" label="Past Illness" />
                        <form:option value="SURGERY" label="Surgery" />
                        <form:option value="FAMILY_HISTORY" label="Family History" />
                    </form:select>
                    <form:errors path="historyType" cssClass="field-error" />
                </div>

                <div class="mb-3">
                    <label for="conditionName" class="form-label fw-semibold">Condition Name</label>
                    <form:input path="conditionName" id="conditionName" cssClass="form-control" />
                    <form:errors path="conditionName" cssClass="field-error" />
                </div>

                <div class="mb-3">
                    <label for="diagnosedYear" class="form-label fw-semibold">Diagnosed Year</label>
                    <form:input path="diagnosedYear" id="diagnosedYear" type="number" min="1900" cssClass="form-control" />
                    <form:errors path="diagnosedYear" cssClass="field-error" />
                </div>

                <div class="mb-4">
                    <label for="notes" class="form-label fw-semibold">Notes</label>
                    <form:textarea path="notes" id="notes" rows="4" cssClass="form-control" />
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-success">Save History</button>
                    <a href="${pageContext.request.contextPath}/patients/${patient.id}/history" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form:form>
        </div>
    </div>
</div>
</body>
</html>
