<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { margin:0; min-height:100vh; background:#f4f7fb; font-family:Arial,sans-serif; }
        .navbar-custom { background:#0d6efd; }
        .module-card { border:none; border-radius:18px; height:100%; transition:.2s ease; }
        .module-card:hover { transform:translateY(-4px); box-shadow:0 10px 25px rgba(0,0,0,.10); }
        .module-icon { width:55px; height:55px; border-radius:14px; display:flex; align-items:center; justify-content:center; margin-bottom:18px; font-size:24px; font-weight:bold; }
        .patient-icon { background:#e7f1ff; color:#0d6efd; }
        .allergy-icon { background:#fdebec; color:#dc3545; }
        .history-icon { background:#e7f7ed; color:#198754; }
        .users-icon { background:#f1e9ff; color:#6f42c1; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark navbar-custom">
    <div class="container-fluid px-4">
        <span class="navbar-brand fw-bold">EHR System</span>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white fw-semibold">${username}</span>
            <span class="badge bg-light text-primary">${role}</span>
            <a href="${pageContext.request.contextPath}/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="mb-5">
        <h2 class="fw-bold">Dashboard</h2>
        <p class="text-muted">Welcome, ${username}</p>
    </div>

    <div class="row g-4">
        <c:if test="${role == 'ADMIN' || role == 'DOCTOR' || role == 'LAB_TECH'}">
            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon patient-icon">P</div>
                    <h4>Patients</h4>
                    <p class="text-muted">Search and manage patient records.</p>
                    <a href="${pageContext.request.contextPath}/patients" class="btn btn-primary">Open Patients</a>
                </div></div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon allergy-icon">!</div>
                    <h4>Allergies</h4>
                    <p class="text-muted">Select a patient to view allergy records.</p>
                    <a href="${pageContext.request.contextPath}/patients" class="btn btn-danger">Select Patient</a>
                </div></div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon history-icon">H</div>
                    <h4>Medical History</h4>
                    <p class="text-muted">Select a patient to view medical history.</p>
                    <a href="${pageContext.request.contextPath}/patients" class="btn btn-success">Select Patient</a>
                </div></div>
            </div>
        </c:if>

        <c:if test="${role == 'ADMIN'}">
            <div class="col-lg-4 col-md-6">
                <div class="card module-card shadow-sm"><div class="card-body p-4">
                    <div class="module-icon users-icon">U</div>
                    <h4>User Management</h4>
                    <p class="text-muted">Create and view hospital staff login accounts.</p>
                    <a href="${pageContext.request.contextPath}/users" class="btn btn-dark">Manage Users</a>
                </div></div>
            </div>
        </c:if>
    </div>
</div>
</body>
</html>
