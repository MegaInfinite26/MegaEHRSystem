<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .form-card { max-width:760px; margin:auto; border:0; border-radius:16px; }
        .field-error { color:#dc3545; font-size:.875rem; margin-top:.25rem; display:block; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/patients">Patients</a>
    </div>
</nav>

<div class="container py-5">
    <div class="card form-card shadow-sm">
        <div class="card-body p-4 p-md-5">
            <h2 class="fw-bold mb-4">
                <c:choose>
                    <c:when test="${not empty patient.id}">Edit Patient</c:when>
                    <c:otherwise>Register Patient</c:otherwise>
                </c:choose>
            </h2>

            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger">${errorMessage}</div>
            </c:if>

            <c:choose>
                <c:when test="${not empty patient.id}">
                    <c:set var="formAction" value="${pageContext.request.contextPath}/patients/${patient.id}" />
                </c:when>
                <c:otherwise>
                    <c:set var="formAction" value="${pageContext.request.contextPath}/patients" />
                </c:otherwise>
            </c:choose>

            <form:form method="post" action="${formAction}" modelAttribute="patient">
                <div class="mb-3">
                    <label for="name" class="form-label fw-semibold">Name</label>
                    <form:input path="name" id="name" cssClass="form-control" maxlength="80" />
                    <form:errors path="name" cssClass="field-error" />
                </div>

                <div class="mb-3">
                    <label for="dob" class="form-label fw-semibold">Date of Birth</label>
                    <form:input path="dob" id="dob" type="date" cssClass="form-control" />
                    <form:errors path="dob" cssClass="field-error" />
                </div>

                <div class="mb-3">
                    <label for="gender" class="form-label fw-semibold">Gender</label>
                    <form:select path="gender" id="gender" cssClass="form-select">
                        <form:option value="" label="Select gender" />
                        <form:option value="MALE" label="Male" />
                        <form:option value="FEMALE" label="Female" />
                        <form:option value="OTHER" label="Other" />
                    </form:select>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label fw-semibold">Phone</label>
                    <form:input path="phone" id="phone" cssClass="form-control" maxlength="10" />
                    <form:errors path="phone" cssClass="field-error" />
                </div>

                <div class="mb-4">
                    <label for="guardianName" class="form-label fw-semibold">Guardian Name</label>
                    <form:input path="guardianName" id="guardianName" cssClass="form-control" maxlength="100" />
                    <div class="form-text">Required for patients below 18 years.</div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Save Patient</button>
                    <a href="${pageContext.request.contextPath}/patients" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form:form>
        </div>
    </div>
</div>
</body>
</html>
