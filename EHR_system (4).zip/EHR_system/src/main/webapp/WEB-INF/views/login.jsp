<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { margin:0; min-height:100vh; background:#f4f7fb; font-family:Arial,sans-serif; }
        .login-wrapper { min-height:100vh; display:flex; justify-content:center; align-items:center; }
        .login-card { width:100%; max-width:420px; border:0; border-radius:18px; box-shadow:0 8px 30px rgba(0,0,0,.10); }
        .ehr-logo { width:65px; height:65px; margin:0 auto 18px; border-radius:50%; background:#0d6efd; color:#fff; display:flex; align-items:center; justify-content:center; font-size:34px; font-weight:700; }
        .ehr-title { color:#0d6efd; font-weight:700; }
        .form-label { font-weight:600; }
        .form-control { min-height:48px; border-radius:9px; }
        .login-button { min-height:48px; border-radius:9px; font-weight:600; }
    </style>
</head>
<body>
<div class="container">
    <div class="login-wrapper">
        <div class="card login-card">
            <div class="card-body p-5">
                <div class="ehr-logo">+</div>
                <div class="text-center mb-4">
                    <h2 class="ehr-title">EHR System</h2>
                    <p class="text-muted mb-0">Login to continue</p>
                </div>

                <c:if test="${not empty errorMessage}">
                    <div class="alert alert-danger text-center">${errorMessage}</div>
                </c:if>

                <c:if test="${not empty successMessage}">
                    <div class="alert alert-success text-center">${successMessage}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/login" method="post">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username or Email</label>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Enter username or email" autocomplete="username" required>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" autocomplete="current-password" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary login-button">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
