<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Medical History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .content-card { border:0; border-radius:16px; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/patients/${patient.id}">Patient Details</a>
    </div>
</nav>
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Medical History</h2>
            <p class="text-muted mb-0">${patient.name} | ${patient.patientCode}</p>
        </div>
        <c:if test="${pageContext.request.isUserInRole('ADMIN') || pageContext.request.isUserInRole('DOCTOR')}">
            <a href="${pageContext.request.contextPath}/patients/${patient.id}/history/new" class="btn btn-success">+ Add History</a>
        </c:if>
    </div>

    <c:if test="${not empty successMessage}">
        <div class="alert alert-success">${successMessage}</div>
    </c:if>

    <div class="card content-card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th class="ps-4">Type</th>
                        <th>Condition</th>
                        <th>Diagnosed Year</th>
                        <th>Notes</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach var="history" items="${historyList}">
                        <tr>
                            <td class="ps-4 fw-semibold">${history.historyType}</td>
                            <td>${history.conditionName}</td>
                            <td>${history.diagnosedYear}</td>
                            <td>${history.notes}</td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty historyList}">
                        <tr><td colspan="4" class="text-center text-muted py-5">No medical history recorded.</td></tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
