<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EHR System | Add Allergy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f4f7fb; min-height:100vh; }
        .topbar { background:#0d6efd; }
        .form-card { max-width:720px; margin:auto; border:0; border-radius:16px; }
        .field-error { color:#dc3545; font-size:.875rem; display:block; margin-top:.25rem; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark topbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/dashboard">EHR System</a>
        <a class="btn btn-outline-light btn-sm" href="${pageContext.request.contextPath}/patients/${patient.id}/allergies">Allergies</a>
    </div>
</nav>

<div class="container py-5">
    <div class="card form-card shadow-sm">
        <div class="card-body p-4 p-md-5">
            <h2 class="fw-bold mb-1">Add Allergy</h2>
            <p class="text-muted mb-4">${patient.name} | ${patient.patientCode}</p>

            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger">${errorMessage}</div>
            </c:if>

            <form:form method="post"
                       action="${pageContext.request.contextPath}/patients/${patient.id}/allergies"
                       modelAttribute="allergy">

                <div class="mb-3">
                    <label for="allergen" class="form-label fw-semibold">Allergen</label>
                    <form:input path="allergen" id="allergen" cssClass="form-control" />
                    <form:errors path="allergen" cssClass="field-error" />
                </div>

                <div class="mb-3">
                    <label for="reaction" class="form-label fw-semibold">Reaction</label>
                    <form:input path="reaction" id="reaction" cssClass="form-control" />
                    <form:errors path="reaction" cssClass="field-error" />
                </div>

                <div class="mb-4">
                    <label for="severity" class="form-label fw-semibold">Severity</label>
                    <form:select path="severity" id="severity" cssClass="form-select">
                        <form:option value="" label="Select severity" />
                        <form:option value="MILD" label="Mild" />
                        <form:option value="MODERATE" label="Moderate" />
                        <form:option value="SEVERE" label="Severe" />
                    </form:select>
                    <form:errors path="severity" cssClass="field-error" />
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-danger">Save Allergy</button>
                    <a href="${pageContext.request.contextPath}/patients/${patient.id}/allergies" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form:form>
        </div>
    </div>
</div>
</body>
</html>
