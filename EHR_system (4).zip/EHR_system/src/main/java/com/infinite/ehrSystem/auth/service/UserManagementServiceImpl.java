package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.UserCreateDto;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.entity.UserStatus;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.role.entity.Role;
import com.infinite.ehrSystem.role.repository.RoleRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
@Transactional
public class UserManagementServiceImpl implements UserManagementService {

    private static final Set<String> STAFF_ROLES =
            Set.of("ADMIN", "DOCTOR", "LAB_TECH");

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserManagementServiceImpl(
            UserRepository userRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getAllStaffUsers() {
        return userRepository.findAll()
                .stream()
                .filter(user -> STAFF_ROLES.contains(user.getRole().getName().toUpperCase()))
                .toList();
    }

    @Override
    public User createStaffUser(UserCreateDto dto) {

        String username = dto.getUsername().trim();
        String email = dto.getEmail().trim().toLowerCase();
        String roleName = dto.getRoleName().trim().toUpperCase();

        if (!STAFF_ROLES.contains(roleName)) {
            throw new IllegalArgumentException("Only ADMIN, DOCTOR or LAB_TECH staff accounts can be created here");
        }

        if (userRepository.existsByUsername(username)) {
            throw new IllegalArgumentException("Username already exists");
        }

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email already exists");
        }

        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new IllegalArgumentException("Selected role does not exist"));

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole(role);
        user.setStatus(UserStatus.ACTIVE);
        user.setFailedAttempts(0);

        return userRepository.save(user);
    }
}
