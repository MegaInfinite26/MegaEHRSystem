package com.infinite.ehrSystem.allergy.controller;

import com.infinite.ehrSystem.allergy.dto.AllergyDTO;
import com.infinite.ehrSystem.allergy.service.AllergyService;
import com.infinite.ehrSystem.patient.dto.PatientDto;
import com.infinite.ehrSystem.patient.service.PatientService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.UUID;


@Controller
public class AllergyController {

    private final AllergyService allergyService;
    private final PatientService patientService;


    public AllergyController(
            AllergyService allergyService,
            PatientService patientService) {

        this.allergyService = allergyService;
        this.patientService = patientService;
    }


    // =====================================================
    // REST API - GET ALLERGIES
    // ADMIN / DOCTOR / LAB_TECH
    // =====================================================

    @GetMapping("/api/patients/{patientId}/allergies")
    @ResponseBody
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR','LAB_TECH')"
    )
    public ResponseEntity<List<AllergyDTO>> getAllergiesApi(
            @PathVariable UUID patientId) {

        return ResponseEntity.ok(
                allergyService.getAllergies(patientId)
        );
    }


    // =====================================================
    // REST API - ADD ALLERGY
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @PostMapping("/api/patients/{patientId}/allergies")
    @ResponseBody
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public ResponseEntity<AllergyDTO> addAllergyApi(
            @PathVariable UUID patientId,
            @Valid @RequestBody AllergyDTO allergyDTO) {

        AllergyDTO createdAllergy =
                allergyService.addAllergy(
                        patientId,
                        allergyDTO
                );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdAllergy);
    }


    // =====================================================
    // JSP - VIEW ALLERGY LIST
    // ADMIN / DOCTOR / LAB_TECH
    // =====================================================

    @GetMapping("/patients/{patientId}/allergies")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR','LAB_TECH')"
    )
    public String allergyList(
            @PathVariable UUID patientId,
            Model model) {

        PatientDto patient =
                patientService.getPatient(patientId);

        List<AllergyDTO> allergies =
                allergyService.getAllergies(patientId);

        model.addAttribute(
                "patient",
                patient
        );

        model.addAttribute(
                "allergies",
                allergies
        );

        return "allergy-list";
    }


    // =====================================================
    // JSP - OPEN ADD ALLERGY FORM
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @GetMapping("/patients/{patientId}/allergies/new")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public String showAllergyForm(
            @PathVariable UUID patientId,
            Model model) {

        PatientDto patient =
                patientService.getPatient(patientId);

        AllergyDTO allergyDTO =
                new AllergyDTO();

        allergyDTO.setPatientId(
                patientId
        );

        model.addAttribute(
                "patient",
                patient
        );

        model.addAttribute(
                "allergy",
                allergyDTO
        );

        return "allergy-form";
    }


    // =====================================================
    // JSP - SAVE ALLERGY
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @PostMapping("/patients/{patientId}/allergies")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public String addAllergy(
            @PathVariable UUID patientId,

            @Valid
            @ModelAttribute("allergy")
            AllergyDTO allergyDTO,

            BindingResult bindingResult,

            Model model,

            RedirectAttributes redirectAttributes) {


        if (bindingResult.hasErrors()) {

            model.addAttribute(
                    "patient",
                    patientService.getPatient(patientId)
            );

            return "allergy-form";
        }


        try {

            allergyService.addAllergy(
                    patientId,
                    allergyDTO
            );


            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Allergy added successfully"
            );


            return "redirect:/patients/"
                    + patientId
                    + "/allergies";


        } catch (RuntimeException exception) {

            model.addAttribute(
                    "patient",
                    patientService.getPatient(patientId)
            );

            model.addAttribute(
                    "errorMessage",
                    exception.getMessage()
            );

            return "allergy-form";
        }
    }
}