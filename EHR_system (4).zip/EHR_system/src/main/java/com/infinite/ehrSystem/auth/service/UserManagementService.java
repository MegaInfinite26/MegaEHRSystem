package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.UserCreateDto;
import com.infinite.ehrSystem.auth.entity.User;

import java.util.List;

public interface UserManagementService {

    List<User> getAllStaffUsers();

    User createStaffUser(UserCreateDto userCreateDto);
}
