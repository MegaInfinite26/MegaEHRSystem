package com.infinite.ehrSystem.medicalhistory.controller;

import com.infinite.ehrSystem.medicalhistory.dto.MedicalHistoryDto;
import com.infinite.ehrSystem.medicalhistory.service.MedicalHistoryService;
import com.infinite.ehrSystem.patient.dto.PatientDto;
import com.infinite.ehrSystem.patient.service.PatientService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.UUID;


@Controller
public class MedicalHistoryController {

    private final MedicalHistoryService medicalHistoryService;
    private final PatientService patientService;


    public MedicalHistoryController(
            MedicalHistoryService medicalHistoryService,
            PatientService patientService) {

        this.medicalHistoryService = medicalHistoryService;
        this.patientService = patientService;
    }


    // =====================================================
    // REST API - VIEW MEDICAL HISTORY
    // ADMIN / DOCTOR / LAB_TECH
    // =====================================================

    @GetMapping("/api/patients/{patientId}/history")
    @ResponseBody
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR','LAB_TECH')"
    )
    public ResponseEntity<List<MedicalHistoryDto>> getHistoryApi(
            @PathVariable UUID patientId) {

        return ResponseEntity.ok(
                medicalHistoryService.getHistory(patientId)
        );
    }


    // =====================================================
    // REST API - ADD MEDICAL HISTORY
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @PostMapping("/api/patients/{patientId}/history")
    @ResponseBody
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public ResponseEntity<MedicalHistoryDto> addHistoryApi(
            @PathVariable UUID patientId,
            @Valid @RequestBody MedicalHistoryDto medicalHistoryDto) {

        MedicalHistoryDto created =
                medicalHistoryService.addHistory(
                        patientId,
                        medicalHistoryDto
                );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(created);
    }


    // =====================================================
    // JSP - VIEW MEDICAL HISTORY
    // ADMIN / DOCTOR / LAB_TECH
    // =====================================================

    @GetMapping("/patients/{patientId}/history")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR','LAB_TECH')"
    )
    public String historyList(
            @PathVariable UUID patientId,
            Model model) {

        PatientDto patient =
                patientService.getPatient(patientId);

        model.addAttribute(
                "patient",
                patient
        );

        model.addAttribute(
                "historyList",
                medicalHistoryService.getHistory(patientId)
        );

        return "history-list";
    }


    // =====================================================
    // JSP - OPEN ADD HISTORY FORM
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @GetMapping("/patients/{patientId}/history/new")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public String showHistoryForm(
            @PathVariable UUID patientId,
            Model model) {

        PatientDto patient =
                patientService.getPatient(patientId);

        MedicalHistoryDto history =
                new MedicalHistoryDto();

        history.setPatientId(
                patientId
        );

        model.addAttribute(
                "patient",
                patient
        );

        model.addAttribute(
                "history",
                history
        );

        return "history-form";
    }


    // =====================================================
    // JSP - SAVE MEDICAL HISTORY
    // ADMIN / DOCTOR ONLY
    // =====================================================

    @PostMapping("/patients/{patientId}/history")
    @PreAuthorize(
            "hasAnyRole('ADMIN','DOCTOR')"
    )
    public String addHistory(
            @PathVariable UUID patientId,

            @Valid
            @ModelAttribute("history")
            MedicalHistoryDto medicalHistoryDto,

            BindingResult bindingResult,

            Model model,

            RedirectAttributes redirectAttributes) {


        if (bindingResult.hasErrors()) {

            model.addAttribute(
                    "patient",
                    patientService.getPatient(patientId)
            );

            return "history-form";
        }


        try {

            medicalHistoryService.addHistory(
                    patientId,
                    medicalHistoryDto
            );


            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Medical history added successfully"
            );


            return "redirect:/patients/"
                    + patientId
                    + "/history";


        } catch (RuntimeException exception) {

            model.addAttribute(
                    "patient",
                    patientService.getPatient(patientId)
            );

            model.addAttribute(
                    "errorMessage",
                    exception.getMessage()
            );

            return "history-form";
        }
    }
}