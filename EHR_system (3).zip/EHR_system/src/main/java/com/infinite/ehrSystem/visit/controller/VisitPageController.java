package com.infinite.ehrSystem.visit.controller;

import com.infinite.ehrSystem.visit.dto.VisitDTO;
import com.infinite.ehrSystem.visit.service.VisitService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Controller
@RequestMapping("/visits")
@RequiredArgsConstructor
public class VisitPageController {

    private final VisitService visitService;

    @GetMapping
    public String visitListPage(Model model) {

        model.addAttribute(
                "visits",
                visitService.getAllVisits()
        );

        return "visit/visit-list";
    }

    @GetMapping("/new")
    public String openVisitForm(Model model) {

        model.addAttribute(
                "visit",
                new VisitDTO()
        );

        return "visit/visit-form";
    }

    @PostMapping("/save")
    public String saveVisit(
            @ModelAttribute("visit")
            VisitDTO visitDTO) {

        visitService.createVisit(
                visitDTO
        );

        return "redirect:/visits";
    }

    @GetMapping("/details/{id}")
    public String visitDetails(
            @PathVariable UUID id,
            Model model) {

        model.addAttribute(
                "visit",
                visitService.getVisitById(id)
        );

        return "visit/visit-detail";
    }

    @PostMapping("/close/{id}")
    public String closeVisit(
            @PathVariable UUID id) {

        visitService.closeVisit(id);

        return "redirect:/visits";
    }

    @GetMapping("/test")
    @ResponseBody
    public String test() {

        return "Visit Page Controller Working";
    }
}