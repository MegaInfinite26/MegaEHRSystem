<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<html>

<head>

    <title>Visit List</title>

</head>

<body>

<h2>Visit Management</h2>

${pageContext.request.contextPath}/visits/new

    Open New Visit

</a>

<br><br>

<table border="1" cellpadding="10">

    <thead>

    <tr>

        <th>Visit Code</th>

        <th>Patient</th>

        <th>Visit Date</th>

        <th>Status</th>

        <th>Actions</th>

    </tr>

    </thead>

    <tbody>

    <c:forEach items="${visits}"
               var="visit">

        <tr>

            <td>

                ${visit.visitCode}

            </td>

            <td>

                ${visit.patientCode}
                -
                ${visit.patientName}

            </td>

            <td>

                ${visit.visitDate}

            </td>

            <td>

                ${visit.status}

            </td>

            <td>

                ${pageContext.request.contextPath}/visits/details/${visit.id}

                    View

                </a>

                <c:if test="${visit.status == 'OPEN'}">

                    ${pageContext.request.contextPath}/visits/close/${visit.id}

                        <button type="submit">

                            Close

                        </button>

                    </form>

                </c:if>

            </td>

        </tr>

    </c:forEach>

    </tbody>

</table>

</body>

</html>