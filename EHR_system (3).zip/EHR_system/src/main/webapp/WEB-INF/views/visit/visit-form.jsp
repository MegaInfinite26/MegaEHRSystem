<%@ page contentType="text/html;charset=UTF-8" %>

<html>

<head>
    <title>Open Visit</title>
</head>

<body>

<h2>Open Visit</h2>

${pageContext.request.contextPath}/visits/save

    <table>

        <tr>
            <td>Patient ID</td>
            <td>
                <input type="text"
                       name="patientId"
                       required>
            </td>
        </tr>

        <tr>
            <td>Doctor ID</td>
            <td>
                <input type="text"
                       name="doctorId"
                       required>
            </td>
        </tr>

        <tr>
            <td>Visit Date & Time</td>
            <td>
                <input type="datetime-local"
                       name="visitDate">
            </td>
        </tr>

        <tr>
            <td colspan="2">

                <button type="submit">

                    Open Visit

                </button>

            </td>
        </tr>

    </table>

</form>

<br>

${pageContext.request.contextPath}/visits

    Back To Visit List

</a>

</body>

</html>