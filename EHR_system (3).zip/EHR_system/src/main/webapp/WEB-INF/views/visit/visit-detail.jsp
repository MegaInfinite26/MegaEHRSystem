<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<html>

<head>

    <title>Visit Details</title>

</head>

<body>

<h2>Visit Details</h2>

<table border="1" cellpadding="10">

    <tr>
        <td><b>Visit Code</b></td>
        <td>${visit.visitCode}</td>
    </tr>

    <tr>
        <td><b>Patient</b></td>
        <td>
            ${visit.patientCode}
            -
            ${visit.patientName}
        </td>
    </tr>

    <tr>
        <td><b>Doctor ID</b></td>
        <td>${visit.doctorId}</td>
    </tr>

    <tr>
        <td><b>Visit Date</b></td>
        <td>${visit.visitDate}</td>
    </tr>

    <tr>
        <td><b>Status</b></td>
        <td>${visit.status}</td>
    </tr>

</table>

<br>

<h3>Audit Information</h3>

<table border="1" cellpadding="10">

    <tr>
        <td><b>Created By</b></td>
        <td>${visit.createdBy}</td>
    </tr>

    <tr>
        <td><b>Created On</b></td>
        <td>${visit.createdOn}</td>
    </tr>

    <tr>
        <td><b>Updated By</b></td>
        <td>${visit.updatedBy}</td>
    </tr>

    <tr>
        <td><b>Updated On</b></td>
        <td>${visit.updatedOn}</td>
    </tr>

</table>

<br>

${pageContext.request.contextPath}/visits

    Back To Visit List

</a>

</body>

</html>